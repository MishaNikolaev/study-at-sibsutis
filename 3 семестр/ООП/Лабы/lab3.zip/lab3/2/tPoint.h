#ifndef TPOINT_H
#define TPOINT_H

class tPoint
{
private:
    int x;
    int y;
    int dx;
    int dy;

public:
    tPoint();
    tPoint(int x, int y);
    void getCoordinates(int &cordX, int &cordY);
    void draw();
    void moveStraight(int width, int height);
    void moveRandomly(int width, int height);
};

#endif

