#include "tPoint.h"
#include <graphics.h>
#include <cstdlib>

tPoint::tPoint() : x(0), y(0), dx(1), dy(1) {}

tPoint::tPoint(int x, int y) : x(x), y(y) {
    dx = (rand() % 2 == 0) ? 1 : -1;
    dy = (rand() % 2 == 0) ? 1 : -1;
}

void tPoint::getCoordinates(int &cordX, int &cordY) {
    cordX = x;
    cordY = y;
}

void tPoint::draw() {
    setcolor(WHITE);
    setfillstyle(SOLID_FILL, WHITE);
    fillellipse(x, y, 2, 2);
}

void tPoint::moveStraight(int width, int height) {
    x += dx;
    y += dy;
    if (x <= 0 || x >= width) dx = -dx;
    if (y <= 0 || y >= height) dy = -dy;
}

void tPoint::moveRandomly(int width, int height) {
    dx = (rand() % 5) - 2;
    dy = (rand() % 5) - 2;
    x += dx;
    y += dy;
    if (x < 0) x = 0;
    else if (x >= width) x = width - 1;
    if (y < 0) y = 0;
    else if (y >= height) y = height - 1;
}
