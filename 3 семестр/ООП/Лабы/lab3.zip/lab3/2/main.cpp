#include <iostream>
#include <cstdlib>
#include <ctime>
#include <graphics.h>
#include "tPoint.h"

const int POINT_COUNT = 100;

int main() {
    int gd = DETECT, gm;
    initgraph(&gd, &gm, "");

    srand(time(0));

    tPoint* points = new tPoint[POINT_COUNT];

    for (int i = 0; i < POINT_COUNT; ++i) {
        int x = rand() % getmaxx();
        int y = rand() % getmaxy();
        points[i] = tPoint(x, y);
    }

    bool useStraightMovement = true;

    while (true) {
        if (kbhit()) {
            char key = getch();
            if (key == 'S' || key == 's') useStraightMovement = true;
            else if (key == 'R' || key == 'r') useStraightMovement = false;
            else if (key == 27) break;
        }

        cleardevice();
        for (int i = 0; i < POINT_COUNT; ++i) {
            points[i].draw();
            if (useStraightMovement) points[i].moveStraight(getmaxx(), getmaxy());
            else points[i].moveRandomly(getmaxx(), getmaxy());
        }
        delay(10);
    }

    delete[] points;
    closegraph();
    return 0;
}
