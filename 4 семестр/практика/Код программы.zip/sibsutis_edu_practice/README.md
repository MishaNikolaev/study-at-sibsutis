# sibsutis_edu_practice

loading data using kinopoisk API for fetching films.

Misha branch - feature1
Gleb branch - feature2

This is our project what we did during universities practice.

**Algorythms**

We had been faced with inject search in our project. So we decided that it will be binary search.
For this reason we did sort. In our case it was quick sort algorythm:

```python
  def QuickSort(self, movies: List[Movie], L: int, R: int) -> None:
        while L < R:
            i, j = L, R
            pivot = movies[L].name.lower()

            while i <= j:
                while movies[i].name.lower() < pivot:
                    i += 1
                while movies[j].name.lower() > pivot:
                    j -= 1
                if i <= j:
                    movies[i], movies[j] = movies[j], movies[i]
                    i += 1
                    j -= 1

            if (j - L) < (R - i):
                self.QuickSort(movies, L, j)
                L = i
            else:
                self.QuickSort(movies, i, R)
                R = j
```

Then we did binary search
```python
    def binary_search(self, sorted_movies: List[Movie], query: str) -> List[Movie]:
        if not query:
            return []

        query = query.lower()
        left, right = 0, len(sorted_movies) - 1

        while left < right:
            mid = (left + right) // 2
            if sorted_movies[mid].name.lower() >= query:
                right = mid
            else:
                left = mid + 1

        result = []
        while left < len(sorted_movies) and query in sorted_movies[left].name.lower():
            result.append(sorted_movies[left])
            left += 1

        return result

    def search_movies(self, movies: List[Movie], query: str) -> List[Movie]:
        if not query:
            return []

        sorted_movies = movies.copy()
        self.QuickSort(sorted_movies, 0, len(sorted_movies) - 1)
        return self.binary_search(sorted_movies, query)
```

Besides you can take a look on our UI:
![logs](https://github.com/MishaNikolaev/sibsutis_edu_practice/blob/main/data/assets/films.jpg)

**Architecture**
We can be sure that our code is clean, cause it's divided by few layers: data, presentation and domain and all of them are connect with each other:
![logs](https://github.com/MishaNikolaev/sibsutis_edu_practice/blob/main/data/assets/structure.jpg)

**How to execute our project?**
As you can see there is file "config.py". You need to insert your api key. You can get it there: https://www.kinopoisk.ru/lists/movies/top250/?utm_referrer=yandex.ru
