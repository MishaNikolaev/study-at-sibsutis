API_KEY = 'GMZQN7J-T8CM8E6-KP1BHPG-FQSPNZ5'
API_URL = 'https://api.kinopoisk.dev/v1.3/movie'
