from tkinter import messagebox, Frame, Label, Button, Entry, Canvas, Scrollbar
from typing import List
from domain.models import Movie
from infrastructure.storage.image_storage import ImageStorage
from colorama import Fore, Style, init
from infrastructure.repository.movie_repository import MovieRepository


class MovieUI:
    def __init__(self, root):
        self.root = root
        self.movies: List[Movie] = []
        self.movies_for_search: List[Movie] = []
        self.page = 1
        self.print_in_terminal = True
        
        self.image_storage = ImageStorage('data/images')
        self.setup_ui()
        init(autoreset=True)
        
    def setup_ui(self):
        self.root.title("Кинопоиск: Топ 250 фильмов")
        self.root.geometry("650x700")
        
        self.setup_navigation()
        
        self.setup_scrollable_area()
        
    def setup_navigation(self):
        nav_frame = Frame(self.root, bg="lightgray", pady=10)
        nav_frame.pack(fill="x")

        Button(nav_frame, text="← Предыдущая", command=self.prev_page, font=("Arial", 8)).pack(side="left", padx=5)
        Button(nav_frame, text="Следующая →", command=self.next_page, font=("Arial", 8)).pack(side="left", padx=0)

        self.page_entry = Entry(nav_frame, width=10)
        self.page_entry.pack(side="left", padx=10)
        Button(nav_frame, text="Перейти", command=self.go_to_page).pack(side="left", padx=10)

        self.page_label = Label(nav_frame, text=f"Номер страницы: {self.page}", font=("Arial", 8))
        self.page_label.pack(side="left")

        Button(nav_frame, text="Поиск", command=self.start_search, font=("Arial", 8)).pack(side="left", padx=5)
        Button(nav_frame, text="Окончить поиск", command=self.end_search, font=("Arial", 6)).pack(side="left")

        self.search_entry = Entry(nav_frame, font=("Arial", 12), width=10)
        self.search_entry.pack(side="left", padx=5)

    def setup_scrollable_area(self):
        self.canvas = Canvas(self.root, bg="white")
        self.scrollbar = Scrollbar(self.root, orient="vertical", command=self.canvas.yview)

        self.canvas.configure(yscrollcommand=self.scrollbar.set)
        self.canvas.bind('<Configure>', lambda e: self.canvas.configure(scrollregion=self.canvas.bbox("all")))

        self.scrollbar.pack(side="right", fill="y")
        self.canvas.pack(side="left", fill="both", expand=True)

        self.movie_frame = Frame(self.canvas, bg="white")
        self.canvas.create_window((0, 0), window=self.movie_frame, anchor="nw")

    def create_movie_cards(self, movies: List[Movie]):
        for widget in self.movie_frame.winfo_children():
            widget.destroy()

        for movie in movies:
            self.create_movie_card(movie)
            if self.print_in_terminal:
                self.print_movie_to_console(movie)

    def create_movie_card(self, movie: Movie):
        movie_item_frame = Frame(self.movie_frame, bg="white", bd=2, relief="groove")
        movie_item_frame.pack(fill="x", pady=5, padx=10, expand=True)
        
        poster_image = self.image_storage.get_image(movie.poster_url)
        poster_frame = Frame(movie_item_frame, bg="white")
        poster_frame.pack(side="left", padx=10, pady=10)
        
        if poster_image:
            poster_label = Label(poster_frame, image=poster_image, bg="white")
            poster_label.image = poster_image
            poster_label.pack()

        info_frame = Frame(movie_item_frame, bg="white")
        info_frame.pack(side="left", fill="both", expand=True, padx=10, pady=10)
        
        name_label = Label(info_frame, text=movie.name, bg="white", font=("Arial", 12, "bold"))
        name_label.pack(anchor="w")
        
        rating_frame = Frame(info_frame, bg="white")
        rating_frame.pack(anchor="w")
        Label(rating_frame, text=f"Рейтинг: {movie.rating}", bg="white", font=("Arial", 12)).pack(side="left")
        Label(rating_frame, text="⭐", fg="gold", bg="white", font=("Arial", 12)).pack(side="left", padx=5)
        
        info_text = (
            f"Год: {movie.year}\n"
            f"Жанры: {', '.join(movie.genres)}\n"
            f"Страны: {', '.join(movie.countries)}"
        )
        Label(info_frame, text=info_text, bg="white", justify="left", font=("Arial", 12)).pack(anchor="w")

    def print_movie_to_console(self, movie: Movie):
        color = self.get_color_by_genre(movie.genres)
        print(f"{color}{movie.name}")
        print(f"Рейтинг: {movie.rating}")
        print(f"Год: {movie.year}")
        print(f"Жанры: {', '.join(movie.genres)}")
        print(f"Страны: {', '.join(movie.countries)}")
        print("-" * 40)

    def get_color_by_genre(self, genres: List[str]):
        genre_colors = {
            'драма': Fore.RED,
            'комедия': Fore.GREEN,
            'боевик': Fore.YELLOW,
            'фантастика': Fore.BLUE,
            'триллер': Fore.MAGENTA,
            'мелодрама': Fore.CYAN,
            'детектив': Fore.WHITE,
        }
        for genre in genres:
            if genre.lower() in genre_colors:
                return genre_colors[genre.lower()]
        return Fore.WHITE

    def update_movies_display(self, movies: List[Movie]):
        start_idx = (self.page - 1) * 10
        end_idx = self.page * 10
        movies_to_show = movies[start_idx:end_idx]

        if movies_to_show:
            self.page_label.config(text=f"Номер страницы: {self.page}")
            self.create_movie_cards(movies_to_show)
            return True
        else:
            messagebox.showinfo("Информация", "Фильмы закончились или произошла ошибка.")
            return False

    def prev_page(self):
        if self.page > 1:
            self.page -= 1
            self.update_movies_display(self.movies)

    def next_page(self):
        self.page += 1
        if not self.update_movies_display(self.movies):
            self.page -= 1

    def go_to_page(self):
        try:
            new_page = int(self.page_entry.get()) if self.page_entry.get().isdigit() else 0
            if 0 < new_page <= (len(self.movies) // 10 + 1):
                self.page = new_page
                self.update_movies_display(self.movies)
                return True
            else:
                messagebox.showwarning("Ошибка", "Некорректный номер страницы.")
                return False
        except ValueError:
            messagebox.showwarning("Ошибка", "Введите число.")
            return False

    def start_search(self):
        key = self.search_entry.get()
        if key:
            if not self.movies_for_search:
                self.movies_for_search = self.movies.copy()
                repo = MovieRepository()
                repo.QuickSort(self.movies_for_search, 0, len(self.movies_for_search) - 1)

            repo = MovieRepository()
            found_movies = repo.binary_search(self.movies_for_search, key)
            self.create_movie_cards(found_movies)

    def end_search(self):
        self.search_entry.delete(0, 'end')
        self.update_movies_display(self.movies)