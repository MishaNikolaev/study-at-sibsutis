import requests
from config import API_KEY, API_URL

class KinopoiskAPI:
    def __init__(self):
        self.headers = {'X-API-KEY': API_KEY}
        self.base_url = API_URL
        
    def get_top250(self):
        params = {
            'selectFields': ['name', 'rating.kp', 'year', 'genres.name', 'countries.name', 'poster.url'],
            'lists': 'top250',
            'limit': 250
        }
        try:
            response = requests.get(self.base_url, headers=self.headers, params=params, timeout=10)
            if response.status_code == 200:
                return response.json().get('docs', [])
        except requests.RequestException:
            return []
        return []
