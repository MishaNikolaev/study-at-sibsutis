import json
from pathlib import Path
import os

class CacheManager:
    def __init__(self, cache_path: str):
        self.cache_path = Path(cache_path)
        os.makedirs(self.cache_path.parent, exist_ok=True)

    def load(self):
        try:
            with open(self.cache_path, 'r', encoding='utf-8') as f:
                return json.load(f)
        except (FileNotFoundError, json.JSONDecodeError):
            return None

    def save(self, data):
        with open(self.cache_path, 'w', encoding='utf-8') as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
