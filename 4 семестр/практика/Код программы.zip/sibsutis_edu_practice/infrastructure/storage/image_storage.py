import os
from hashlib import md5
from PIL import Image, ImageTk
from io import BytesIO
import requests

class ImageStorage:
    def __init__(self, cache_dir: str):
        self.cache_dir = cache_dir
        os.makedirs(cache_dir, exist_ok=True)
        
    def get_image(self, url: str, size=(136, 204)):
        if not url:
            return None
            
        cache_name = f"{md5(url.encode()).hexdigest()}_{size[0]}x{size[1]}.png"
        cache_path = os.path.join(self.cache_dir, cache_name)
        
        if os.path.exists(cache_path):
            try:
                return ImageTk.PhotoImage(Image.open(cache_path))
            except Exception:
                os.remove(cache_path)
                
        try:
            response = requests.get(url, timeout=10)
            if response.status_code == 200:
                img = Image.open(BytesIO(response.content))
                img = img.resize(size, Image.LANCZOS)
                img.save(cache_path, "PNG")
                return ImageTk.PhotoImage(img)
        except Exception:
            return None
