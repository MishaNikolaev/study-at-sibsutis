from typing import List
from domain.models import Movie
from infrastructure.api.kinopoisk_api import KinopoiskAPI
from infrastructure.cache.cache_manager import CacheManager
from functools import lru_cache
from domain.movie_Irepository import IMovieRepository


class MovieRepository(IMovieRepository):
    def __init__(self):
        self.api = KinopoiskAPI()
        self.cache = CacheManager('data/cache/movies_cache.json')

    @lru_cache(maxsize=1)
    def get_top250(self) -> List[Movie]:
        cached = self.cache.load()
        if cached:
            return [Movie.from_dict(m) for m in cached]

        data = self.api.get_top250()
        if data:
            self.cache.save(data)
            return [Movie.from_dict(m) for m in data]
        return []

    def QuickSort(self, movies: List[Movie], L: int, R: int) -> None:
        while L < R:
            i, j = L, R
            pivot = movies[L].name.lower()

            while i <= j:
                while movies[i].name.lower() < pivot:
                    i += 1
                while movies[j].name.lower() > pivot:
                    j -= 1
                if i <= j:
                    movies[i], movies[j] = movies[j], movies[i]
                    i += 1
                    j -= 1

            if (j - L) < (R - i):
                self.QuickSort(movies, L, j)
                L = i
            else:
                self.QuickSort(movies, i, R)
                R = j

    def binary_search(self, sorted_movies: List[Movie], query: str) -> List[Movie]:
        if not query:
            return []

        query = query.lower()
        left, right = 0, len(sorted_movies) - 1

        while left < right:
            mid = (left + right) // 2
            if sorted_movies[mid].name.lower() >= query:
                right = mid
            else:
                left = mid + 1

        result = []
        while left < len(sorted_movies) and query in sorted_movies[left].name.lower():
            result.append(sorted_movies[left])
            left += 1

        return result

    def search_movies(self, movies: List[Movie], query: str) -> List[Movie]:
        if not query:
            return []

        sorted_movies = movies.copy()
        self.QuickSort(sorted_movies, 0, len(sorted_movies) - 1)
        return self.binary_search(sorted_movies, query)

    def sort_movies(self, movies: List[Movie]) -> List[Movie]:
        sorted_movies = movies.copy()
        self.QuickSort(sorted_movies, 0, len(sorted_movies) - 1)
        return sorted_movies