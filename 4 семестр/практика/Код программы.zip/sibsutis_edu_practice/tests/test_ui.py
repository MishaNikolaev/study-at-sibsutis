import pytest
from unittest.mock import Mock, patch, MagicMock
from ui.movie_ui import MovieUI
import tkinter as tk
from tkinter import Tk
from domain.models import Movie


@pytest.fixture
def root_window():
    root = Tk()
    yield root
    root.destroy()


def test_navigation_buttons(root_window):
    ui = MovieUI(root_window)
    nav_frame = [w for w in root_window.winfo_children() if isinstance(w, tk.Frame)][0]
    buttons = [w for w in nav_frame.winfo_children() if isinstance(w, tk.Button)]
    assert len(buttons) >= 4, "Navigation buttons are missing"


def test_scrollable_area(root_window):
    ui = MovieUI(root_window)
    canvas = [w for w in root_window.winfo_children() if isinstance(w, tk.Canvas)]
    assert canvas, "Canvas for scrollable area is missing"


def test_scrollbar(root_window):
    ui = MovieUI(root_window)
    assert any(isinstance(widget, tk.Scrollbar) for widget in root_window.winfo_children()), "Scrollbar is missing"


def test_movie_frame(root_window):
    ui = MovieUI(root_window)
    canvas = [w for w in root_window.winfo_children() if isinstance(w, tk.Canvas)]
    assert canvas, "Movie frame is missing"


@patch('ui.movie_ui.ImageStorage')
@patch('ui.movie_ui.Label')
def test_load_image_from_url(mock_label, mock_imagestorage, root_window):
    mock_image = MagicMock()
    mock_imagestorage.return_value.get_image.return_value = mock_image

    ui = MovieUI(root_window)
    test_movie = Movie(
        id="1",
        name="Test Movie",
        year=2020,
        rating=8.0,
        genres=["Drama"],
        countries=["USA"],
        poster_url="test_url"
    )

    ui.create_movie_card(test_movie)

    mock_imagestorage.return_value.get_image.assert_called_once_with("test_url")
    mock_label.assert_called()



# def test_navigation_buttons():
#     root = Tk()
#     MovieRepository(root)
#     nav_frame = [w for w in root.winfo_children() if w.winfo_class() == "Frame"][0]
#     buttons = [w for w in nav_frame.winfo_children() if w.winfo_class() == "Button"]
#     assert len(buttons) >= 4, "Navigation buttons are missing"
#     root.destroy()
#
# def test_scrollable_area():
#     root = Tk()
#     MovieRepository(root)
#     canvas = [w for w in root.winfo_children() if w.winfo_class() == "Canvas"][0]
#     assert canvas is not None, "Canvas for scrollable area is missing"
#     root.destroy()
#
# def test_scrollbar():
#     root = Tk()
#     MovieRepository(root)
#     assert any(widget.winfo_class() == "Scrollbar" for widget in root.winfo_children()), "Scrollbar is missing"
#     root.destroy()
#
# def test_movie_frame():
#     root = Tk()
#     MovieRepository(root)
#     movie_frames = [widget for widget in root.winfo_children() if widget.winfo_class() == "Canvas"]
#     assert movie_frames, "Movie frame is missing"
#     root.destroy()
#
# def test_load_image_from_url():
#     image_url = "https://example.com/sample.jpg"
#     image = MovieRepository(image_url)
#     assert image is None or hasattr(image, "width"), "Image loading function is not returning a valid image"

