import pytest
from unittest.mock import Mock, patch
from infrastructure.repository.movie_repository import MovieRepository
from domain.models import Movie
import requests


class FakeResponse:
    def __init__(self, response_code=200):
        self.status_code = response_code

    def json(self):
        return {'docs': [{'id': '1', 'name': 'Test Movie', 'year': 2020,
                          'rating': {'kp': 8.5}, 'genres': [{'name': 'Drama'}],
                          'countries': [{'name': 'USA'}], 'poster': {'url': 'test_url'}}]}


@pytest.fixture
def mock_movies():
    return [
        Movie(id="1", name="The Shawshank Redemption", year=1994, rating=9.3,
              genres=["Drama"], countries=["USA"], poster_url="url1"),
        Movie(id="2", name="The Godfather", year=1972, rating=9.2,
              genres=["Crime", "Drama"], countries=["USA"], poster_url="url2"),
        Movie(id="3", name="The Dark Knight", year=2008, rating=9.0,
              genres=["Action", "Crime", "Drama"], countries=["USA", "UK"], poster_url="url3"),
    ]


@pytest.fixture(autouse=True)
def mock_kinopoisk_api(monkeypatch):
    monkeypatch.setattr(requests, 'get', lambda *args, **kwargs: FakeResponse())


def test_get_top250_cache_hit():
    repo = MovieRepository()
    repo.cache.load = Mock(return_value=[{'id': '1', 'name': 'Cached Movie'}])
    result = repo.get_top250()
    assert len(result) == 1
    assert result[0].name == "Cached Movie"


def test_get_top250_cache_miss():
    repo = MovieRepository()
    repo.cache.load = Mock(return_value=None)
    repo.api.get_top250 = Mock(return_value=[{'id': '1', 'name': 'API Movie'}])
    repo.cache.save = Mock()

    result = repo.get_top250()
    assert len(result) == 1
    assert result[0].name == "API Movie"
    repo.cache.save.assert_called_once()


def test_quick_sort(mock_movies):
    repo = MovieRepository()
    unsorted = [mock_movies[2], mock_movies[0], mock_movies[1]]  # Dark Knight, Shawshank, Godfather
    expected_order = sorted(unsorted, key=lambda x: x.name.lower())

    repo.QuickSort(unsorted, 0, len(unsorted) - 1)

    result_names = [movie.name for movie in unsorted]
    expected_names = [movie.name for movie in expected_order]
    assert result_names == expected_names, f"Expected order: {expected_names}, got: {result_names}"


def test_binary_search(mock_movies):
    repo = MovieRepository()
    sorted_movies = mock_movies.copy()
    repo.QuickSort(sorted_movies, 0, len(sorted_movies) - 1)

    results = repo.binary_search(sorted_movies, "The Godfather")
    assert len(results) == 1
    assert results[0].name == "The Godfather"

    results = repo.binary_search(sorted_movies, "The")
    assert len(results) == 3
    assert all("The" in movie.name for movie in results)

@patch('requests.get')
def test_api_error(mock_get):
    mock_get.return_value = FakeResponse(404)
    repo = MovieRepository()
    repo.cache.load = Mock(return_value=None)

    result = repo.get_top250()
    assert result == []



#class FakeResponse():
#    def __init__(self,response_code = 200):
#        self.status_code = response_code
#    @staticmethod
#    def json(*args):
#        return {'docs':{"test_movie":"test_vou"}}
#    @staticmethod
#    def get(*args):
#        return

#mock_error = lambda name,text: print(f"{name} {text}")
#mock_plug = lambda *args: 0


#@pytest.fixture(autouse=True)
#def mock_response(monkeypatch):
#    method_mock_response = lambda *args,**kwargs: FakeResponse()
#    monkeypatch.setattr(MovieRepository,"get_page_in_entry",lambda: 5)
#    monkeypatch.setattr(MovieRepository,"update_movies",mock_plug)
#    monkeypatch.setattr(MovieRepository,"show_error",mock_error)
#    monkeypatch.setattr(requests,"get",method_mock_response)
#


#@pytest.fixture
#def mock_response_with_error(monkeypatch):
#    monkeypatch.setattr(MovieRepository,"get_page_in_entry",lambda: -2)
    
#@pytest.fixture
#def mock_response_fetch_error(monkeypatch):
#    monkeypatch.setattr(requests,"get",lambda *args,**kwargs: FakeResponse(404))

#def test_array_for_binary():
#    test_movies =[{
#    "name": "О чём говорят мужчины",
#  },
#  {
#    "name": "Безумный Макс: Дорога ярости"

# },
#    {"name": "Какой-то фильм"},
#{"name": "Зелёный Слоник"}]
#    expected_result = [{"name":"Безумный Макс: Дорога ярости"},
#                       {"name":"Зелёный Слоник"},
#                       {"name":"Какой-то фильм"},
#                       {"name":"О чём говорят мужчины"}]
#    program_result = MovieRepository.create_array_for_binary(test_movies)
#    assert program_result == expected_result
    
#def test_go_to_page():
#   assert MovieRepository.go_to_page()

#def test_go_to_page_error(mock_response_with_error):
#    assert not MovieRepository.go_to_page()

#def test_fetching():
#    fetch = MovieRepository.fetch_movies()
#    assert fetch and MovieRepository.movies == ['test_movie']

#def test_fetching_error(mock_response_fetch_error):
#    fetch = MovieRepository.fetch_movies()
#    assert not fetch

#def test_find_in_json():
#    movies_for_search = [{"name":"Аа??"},{"name":"Вот так вот"},{"name":"Вот я"},{"name":"Гооол"}]
#    key = "Вот"
#    assert MovieRepository.find_in_json(movies_for_search,key) == [{"name":"Вот так вот"},{"name":"Вот я"}]