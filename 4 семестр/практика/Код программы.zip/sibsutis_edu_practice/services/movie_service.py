
from domain.movie_Irepository import IMovieRepository
from domain.models import Movie
from typing import List



class MovieService:
    def __init__(self, repository: IMovieRepository):
        self.repository = repository

    def fetch_movies(self) -> List[Movie]:
        return self.repository.get_top250()

    def search_movies(self, query: str) -> List[Movie]:
        movies = self.repository.get_top250()
        return self.repository.search_movies(movies, query)

    def get_sorted_movies(self) -> List[Movie]:
        movies = self.repository.get_top250()
        return self.repository.sort_movies(movies)
