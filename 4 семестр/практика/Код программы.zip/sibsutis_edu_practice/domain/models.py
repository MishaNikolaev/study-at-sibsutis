from dataclasses import dataclass
from typing import List, Optional, Dict, Any

@dataclass
class Movie:
    id: str
    name: str
    year: int
    rating: float
    genres: List[str]
    countries: List[str]
    poster_url: Optional[str]
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'Movie':
        return cls(
            id=str(data.get('id', '')),
            name=data.get('name', ''),
            year=data.get('year', 0),
            rating=data.get('rating', {}).get('kp', 0.0),
            genres=[g.get('name', '') for g in data.get('genres', [])],
            countries=[c.get('name', '') for c in data.get('countries', [])],
            poster_url=data.get('poster', {}).get('url', None)
        )
