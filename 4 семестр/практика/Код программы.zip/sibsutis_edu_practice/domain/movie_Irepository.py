from abc import ABC, abstractmethod
from typing import List
from domain.models import Movie


class IMovieRepository(ABC):
    @abstractmethod
    def get_top250(self) -> List[Movie]:
        pass

    @abstractmethod
    def search_movies(self, movies: List[Movie], query: str) -> List[Movie]:
        pass

    @abstractmethod
    def sort_movies(self, movies: List[Movie]) -> List[Movie]:
        pass