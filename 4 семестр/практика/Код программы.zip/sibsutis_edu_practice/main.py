import tkinter as tk
from tkinter import messagebox
from ui.movie_ui import MovieUI
from infrastructure.repository.movie_repository import MovieRepository


def main():
    root = tk.Tk()
    repo = MovieRepository()

    movies = repo.get_top250()
    if not movies:
        messagebox.showwarning("Ошибка", "Не удалось загрузить данные.")
        return

    app = MovieUI(root)
    app.movies = movies
    app.movies_for_search = None

    app.update_movies_display(movies)

    root.mainloop()

if __name__ == "__main__":
    main()
